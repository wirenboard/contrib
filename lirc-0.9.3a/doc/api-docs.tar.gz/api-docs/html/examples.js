var examples =
[
    [ "drivers/default/Makefile", "drivers_2default_2Makefile-example.html", null ],
    [ "irexec.cpp", "irexec_8cpp-example.html", null ],
    [ "irsend.cpp", "irsend_8cpp-example.html", null ]
];
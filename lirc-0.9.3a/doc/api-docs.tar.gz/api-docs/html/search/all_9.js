var searchData=
[
  ['ignore_5fmask',['ignore_mask',['../structir__remote.html#a739c26d88eb023d67353fa08dd076255',1,'ir_remote']]],
  ['info',['info',['../structdriver.html#a6b71523700af552255b059ff51a657e1',1,'driver']]],
  ['init_5ffunc',['init_func',['../structdriver.html#a8f50bcc4e1d143a05dd4eba66a4fa7bb',1,'driver']]],
  ['input_5fmap_2ec',['input_map.c',['../input__map_8c.html',1,'']]],
  ['input_5fmap_2eh',['input_map.h',['../input__map_8h.html',1,'']]],
  ['ir_5fcode',['ir_code',['../ir__remote__types_8h.html#af5395595bc25a70e974255b83d97db06',1,'ir_remote_types.h']]],
  ['ir_5fcode_5fnode',['ir_code_node',['../structir__code__node.html',1,'']]],
  ['ir_5fncode',['ir_ncode',['../structir__ncode.html',1,'']]],
  ['ir_5fremote',['ir_remote',['../structir__remote.html',1,'']]],
  ['ir_5fremote_2ec',['ir_remote.c',['../ir__remote_8c.html',1,'']]],
  ['ir_5fremote_2eh',['ir_remote.h',['../ir__remote_8h.html',1,'']]],
  ['ir_5fremote_5finit',['ir_remote_init',['../group__driver__api.html#ga8d5bc121b8582a690000bc8befe13080',1,'ir_remote_init(int use_dyncodes):&#160;ir_remote.c'],['../group__driver__api.html#ga8d5bc121b8582a690000bc8befe13080',1,'ir_remote_init(int use_dyncodes):&#160;ir_remote.c']]],
  ['ir_5fremote_5ftypes_2eh',['ir_remote_types.h',['../ir__remote__types_8h.html',1,'']]],
  ['is_5fin_5fremotes',['is_in_remotes',['../group__driver__api.html#gaadf09b8ef4b71be00f8e53a39f70d315',1,'is_in_remotes(const struct ir_remote *remotes, const struct ir_remote *remote):&#160;ir_remote.c'],['../group__driver__api.html#gaadf09b8ef4b71be00f8e53a39f70d315',1,'is_in_remotes(const struct ir_remote *remotes, const struct ir_remote *remote):&#160;ir_remote.c']]],
  ['internal_20api',['Internal API',['../group__private__api.html',1,'']]]
];

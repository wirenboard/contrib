var searchData=
[
  ['ncode_5fdup',['ncode_dup',['../group__driver__api.html#gac288bce2140d2066a3990a1b2e3317c5',1,'ncode_dup(struct ir_ncode *ncode):&#160;ir_remote.c'],['../group__driver__api.html#gac288bce2140d2066a3990a1b2e3317c5',1,'ncode_dup(struct ir_ncode *ncode):&#160;ir_remote.c']]],
  ['ncode_5ffree',['ncode_free',['../group__driver__api.html#ga4477860d1f604548e032694de8f69c16',1,'ncode_free(struct ir_ncode *ncode):&#160;ir_remote.c'],['../group__driver__api.html#ga4477860d1f604548e032694de8f69c16',1,'ncode_free(struct ir_ncode *ncode):&#160;ir_remote.c']]]
];

var searchData=
[
  ['_5fdictionary_5f',['_dictionary_',['../struct__dictionary__.html',1,'']]]
];

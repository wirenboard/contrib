var searchData=
[
  ['fd',['fd',['../structdriver.html#a277e91c9ef0365654b5412cdcf8cac5f',1,'driver']]],
  ['features',['features',['../structdriver.html#acefa919d82609175b57967c5249020c0',1,'driver']]],
  ['flag',['flag',['../structflaglist.html#afe3283978a321862c7c7705e13206672',1,'flaglist']]],
  ['flaglist',['flaglist',['../structflaglist.html',1,'']]],
  ['flags',['flags',['../structir__remote.html#a9ac03eb6d4cee793010b00fe434aa985',1,'ir_remote']]],
  ['for_5feach_5fdriver',['for_each_driver',['../drv__admin_8c.html#a6611f353b900834d1db0df47632be2ef',1,'for_each_driver(drv_guest_func func, void *arg):&#160;drv_admin.c'],['../drv__admin_8h.html#a6611f353b900834d1db0df47632be2ef',1,'for_each_driver(drv_guest_func func, void *arg):&#160;drv_admin.c']]],
  ['for_5feach_5fplugin',['for_each_plugin',['../drv__admin_8c.html#a9b76aa2090cad96593984bd833c3484c',1,'for_each_plugin(plugin_guest_func plugin_guest, void *arg):&#160;drv_admin.c'],['../drv__admin_8h.html#a9b76aa2090cad96593984bd833c3484c',1,'for_each_plugin(plugin_guest_func plugin_guest, void *arg):&#160;drv_admin.c']]],
  ['free_5fconfig',['free_config',['../group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288',1,'free_config(struct ir_remote *remotes):&#160;config_file.c'],['../group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288',1,'free_config(struct ir_remote *remotes):&#160;config_file.c']]],
  ['freq',['freq',['../structir__remote.html#a04eb04a7c2333f53ceb20ffef8d2ebc4',1,'ir_remote']]]
];

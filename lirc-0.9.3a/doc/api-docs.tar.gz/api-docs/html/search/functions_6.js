var searchData=
[
  ['ir_5fremote_5finit',['ir_remote_init',['../group__driver__api.html#ga8d5bc121b8582a690000bc8befe13080',1,'ir_remote_init(int use_dyncodes):&#160;ir_remote.c'],['../group__driver__api.html#ga8d5bc121b8582a690000bc8befe13080',1,'ir_remote_init(int use_dyncodes):&#160;ir_remote.c']]],
  ['is_5fin_5fremotes',['is_in_remotes',['../group__driver__api.html#gaadf09b8ef4b71be00f8e53a39f70d315',1,'is_in_remotes(const struct ir_remote *remotes, const struct ir_remote *remote):&#160;ir_remote.c'],['../group__driver__api.html#gaadf09b8ef4b71be00f8e53a39f70d315',1,'is_in_remotes(const struct ir_remote *remotes, const struct ir_remote *remote):&#160;ir_remote.c']]]
];

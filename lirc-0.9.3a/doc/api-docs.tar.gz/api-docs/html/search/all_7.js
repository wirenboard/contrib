var searchData=
[
  ['gap',['gap',['../structir__remote.html#ab4e0daf0c0bb06e3feb707c401c92c0e',1,'ir_remote']]],
  ['gap2',['gap2',['../structir__remote.html#a096b15218256835f369f4fa701151971',1,'ir_remote']]],
  ['gap_5fstate',['gap_state',['../structgap__state.html',1,'']]],
  ['get_5fcode_5fby_5fname',['get_code_by_name',['../group__driver__api.html#gafaa7cb5587a3c58e3e825411b966738a',1,'get_code_by_name(const struct ir_remote *remote, const char *name):&#160;ir_remote.c'],['../group__driver__api.html#gafaa7cb5587a3c58e3e825411b966738a',1,'get_code_by_name(const struct ir_remote *remote, const char *name):&#160;ir_remote.c']]],
  ['get_5fdecoding',['get_decoding',['../group__driver__api.html#gaf2e0b982088d231116dea399afa8597f',1,'get_decoding(void):&#160;ir_remote.c'],['../group__driver__api.html#gaf2e0b982088d231116dea399afa8597f',1,'get_decoding(void):&#160;ir_remote.c']]],
  ['get_5ffilter_5fparameters',['get_filter_parameters',['../group__driver__api.html#ga1a1b6c86d0309f25ab5806a5f861692c',1,'get_filter_parameters(const struct ir_remote *remotes, lirc_t *max_gap_lengthp, lirc_t *min_pulse_lengthp, lirc_t *min_space_lengthp, lirc_t *max_pulse_lengthp, lirc_t *max_space_lengthp):&#160;ir_remote.c'],['../group__driver__api.html#ga1a1b6c86d0309f25ab5806a5f861692c',1,'get_filter_parameters(const struct ir_remote *remotes, lirc_t *max_gap_lengthp, lirc_t *min_pulse_lengthp, lirc_t *min_space_lengthp, lirc_t *max_pulse_lengthp, lirc_t *max_space_lengthp):&#160;ir_remote.c']]],
  ['get_5ffrequency_5frange',['get_frequency_range',['../group__driver__api.html#ga19bab2135ca2b7f68dc0b2f8cde9863f',1,'get_frequency_range(const struct ir_remote *remotes, unsigned int *min_freq, unsigned int *max_freq):&#160;ir_remote.c'],['../group__driver__api.html#ga19bab2135ca2b7f68dc0b2f8cde9863f',1,'get_frequency_range(const struct ir_remote *remotes, unsigned int *min_freq, unsigned int *max_freq):&#160;ir_remote.c']]],
  ['get_5fir_5fremote',['get_ir_remote',['../group__driver__api.html#ga251129673cd73c5f869bb53c6c38a88f',1,'get_ir_remote(const struct ir_remote *remotes, const char *name):&#160;ir_remote.c'],['../group__driver__api.html#ga251129673cd73c5f869bb53c6c38a88f',1,'get_ir_remote(const struct ir_remote *remotes, const char *name):&#160;ir_remote.c']]],
  ['get_5fvoid_5farray',['get_void_array',['../config__file_8c.html#a2023c5782f807cd639641f400fda3191',1,'config_file.c']]],
  ['goldstar',['GOLDSTAR',['../ir__remote__types_8h.html#ac3574bc899d70e66c326f73fd8b4b671',1,'ir_remote_types.h']]],
  ['grundig',['GRUNDIG',['../ir__remote__types_8h.html#a40b8ce019aff9658b6afb245bc26b8eb',1,'ir_remote_types.h']]]
];

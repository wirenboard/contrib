var searchData=
[
  ['dictionary',['dictionary',['../group__ciniparser.html#ga5bd3b2ce42b776c76755ec65642f43af',1,'dictionary.h']]],
  ['drv_5fguest_5ffunc',['drv_guest_func',['../drv__admin_8h.html#a66ecd0448214de7b954a4c0307fc1e4b',1,'drv_admin.h']]]
];

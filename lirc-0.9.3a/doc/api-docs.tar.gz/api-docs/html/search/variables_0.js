var searchData=
[
  ['aeps',['aeps',['../structir__remote.html#a0b5643a548247fb44cb323e7f5024ead',1,'ir_remote']]],
  ['all_5fflags',['all_flags',['../config__file_8c.html#a9032e29936c127d0314c1946fdcef80a',1,'config_file.c']]],
  ['api_5fversion',['api_version',['../structdriver.html#a16e4dc8d1f027390afd91294991d932d',1,'driver']]]
];

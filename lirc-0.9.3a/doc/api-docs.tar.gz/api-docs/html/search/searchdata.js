var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuwx",
  1: "_bdfgilmot",
  2: "cdilrstu",
  3: "acdfghilmnorstw",
  4: "abcdefghiklmnoprst",
  5: "adilp",
  6: "_lp",
  7: "bcdglmnprsx",
  8: "cdiu",
  9: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};


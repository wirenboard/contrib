var searchData=
[
  ['name',['name',['../structflaglist.html#a7759b95e8ccf9db09a3a3b839468be71',1,'flaglist::name()'],['../structdriver.html#a2d4bc5861fb0d7bb1684e22a16b7d414',1,'driver::name()'],['../structir__ncode.html#ac28e8133cbc7aa22dbbc8ef722883d2b',1,'ir_ncode::name()'],['../structir__remote.html#acd104de70d9169542de9c471befb0045',1,'ir_remote::name()']]],
  ['ncode',['ncode',['../structbutton__state.html#abcd54bc28722a363e84384100a35399a',1,'button_state']]],
  ['next',['next',['../structir__ncode.html#a0e80278912121f630d3b398959c4dad7',1,'ir_ncode::next()'],['../structlirc__cmd__ctx.html#ad3a65fb2292c86d2e304bc81ba00e8a5',1,'lirc_cmd_ctx::next()']]],
  ['next_5fncode',['next_ncode',['../structir__ncode.html#a0591a65926113978c7db2426c65d9f77',1,'ir_ncode']]]
];

var searchData=
[
  ['baud',['baud',['../structir__remote.html#a9e93a637e00eb62f9118b5059b361f08',1,'ir_remote']]],
  ['bits',['bits',['../structir__remote.html#a66c874209817af89bc88503f61a76539',1,'ir_remote']]],
  ['bits_5fin_5fbyte',['bits_in_byte',['../structir__remote.html#a1fd7f2e6b078e14bc48407ef2db2c406',1,'ir_remote']]],
  ['bo',['BO',['../ir__remote__types_8h.html#a449e8aac922c7f3659cbbf80cf88df10',1,'ir_remote_types.h']]],
  ['buffer',['buffer',['../structlirc__cmd__ctx.html#a88d6468e428af670b4842b5cb91fec77',1,'lirc_cmd_ctx']]],
  ['button_5fstate',['button_state',['../structbutton__state.html',1,'']]]
];

var driver_8h =
[
    [ "DRV_ERR_BAD_OPTION", "group__driver__api.html#gae98bd204d31330f5e862817faadf7f85", null ],
    [ "DRV_ERR_BAD_STATE", "group__driver__api.html#gae323c069918a6b718b3bafd6abbef2a2", null ],
    [ "DRV_ERR_BAD_VALUE", "group__driver__api.html#ga548694fee71123534ede5e27aa4e7e1f", null ],
    [ "DRV_ERR_NOT_IMPLEMENTED", "group__driver__api.html#gab58e0aa64a0fc3769c30e60aaf7061e9", null ],
    [ "DRV_ERR_NOT_IMPLEMENTED", "group__driver__api.html#gab58e0aa64a0fc3769c30e60aaf7061e9", null ],
    [ "DRVCTL_GET_STATE", "group__driver__api.html#ga3637dcda1fb5508e6f51a39b0cc048a7", null ],
    [ "DRVCTL_MAX", "group__driver__api.html#ga2628a2556297a773cddc0848db200d1a", null ],
    [ "DRVCTL_SEND_SPACE", "group__driver__api.html#ga2d4b7ac43bc60cf3d930431f79b2fb89", null ],
    [ "DRVCTL_SET_OPTION", "group__driver__api.html#ga1033feec74cbc16e939d713be2c5b8e0", null ],
    [ "default_close", "group__driver__api.html#ga683dd53e7e5d62746c1a645fe133daf0", null ],
    [ "default_drvctl", "group__driver__api.html#ga96e3243bc45ff488f6c55dde5e9b377b", null ],
    [ "default_open", "group__driver__api.html#gac0f7baaef9fe524365c16022001804d3", null ],
    [ "drv_handle_options", "group__driver__api.html#gaae1b223d2bd3a0d0be6e77019c9a976c", null ],
    [ "curr_driver", "driver_8h.html#a0396ff8d348a185f66f5096ee4f275d5", null ]
];
var structlirc__cmd__ctx =
[
    [ "buffer", "structlirc__cmd__ctx.html#a88d6468e428af670b4842b5cb91fec77", null ],
    [ "head", "structlirc__cmd__ctx.html#adebe3ef131145237834323c6258cf811", null ],
    [ "next", "structlirc__cmd__ctx.html#ad3a65fb2292c86d2e304bc81ba00e8a5", null ],
    [ "packet", "structlirc__cmd__ctx.html#ae0161739995de0b511883c3a0574a8ca", null ],
    [ "reply", "structlirc__cmd__ctx.html#affb9a0be119594fb1ea49deffbf5647d", null ],
    [ "reply_to_stdout", "structlirc__cmd__ctx.html#ac9e5bcea4d878fcc1a4f9a2672fc200e", null ]
];
var structir__code__node =
[
    [ "code", "structir__code__node.html#ad7545b3599e6787d9c274cd1c36b9826", null ],
    [ "next", "structir__code__node.html#ac9f1f3031f2480103f83580924c5b6cd", null ]
];
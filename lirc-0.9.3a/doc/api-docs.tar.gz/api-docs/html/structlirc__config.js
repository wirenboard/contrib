var structlirc__config =
[
    [ "current_mode", "structlirc__config.html#a76841c89a122c06d1d4c6c5df9ac5ffb", null ],
    [ "first", "structlirc__config.html#aa6f3d10abcd1128be8a94199f8c98fdb", null ],
    [ "lircrc_class", "structlirc__config.html#a4531bebf431b9f93e4cc72e8d41e50b6", null ],
    [ "next", "structlirc__config.html#a62b67b70fb0068c9ac2bcd173dae6055", null ],
    [ "sockfd", "structlirc__config.html#aabcf87b01e4100054f99bb1825716f61", null ]
];
var structtoggle__state =
[
    [ "decode_ctx", "structtoggle__state.html#a781bbc70c2e21263d63778a4909a3c95", null ],
    [ "first", "structtoggle__state.html#aeecb2288f042b85fd8fea0d6a64804ed", null ],
    [ "flag", "structtoggle__state.html#a77c44b44283feeea96eb27bb26bdcbfc", null ],
    [ "found", "structtoggle__state.html#ae054767bc6a4223c4637bd21f08e0df1", null ],
    [ "inited", "structtoggle__state.html#a0a84ea434711a41831f0a9c96287aeac", null ],
    [ "last", "structtoggle__state.html#a8bcfd9326836cb56b4a1097616480cfa", null ],
    [ "repeats", "structtoggle__state.html#a6204c61faf6b6e4cc2e8f51939194417", null ],
    [ "retries", "structtoggle__state.html#a33297da9add778508f38f981db1e293c", null ],
    [ "retval", "structtoggle__state.html#af44661ce029f200bc0ef01322a05eb86", null ],
    [ "seq", "structtoggle__state.html#ab537bd685b5a4b97bfcd62228dc1266d", null ],
    [ "success", "structtoggle__state.html#af069f80f774f75600f480fd959a1253a", null ]
];
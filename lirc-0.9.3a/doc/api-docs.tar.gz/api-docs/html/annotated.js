var annotated =
[
    [ "_dictionary_", "struct__dictionary__.html", "struct__dictionary__" ],
    [ "button_state", "structbutton__state.html", "structbutton__state" ],
    [ "decode_ctx_t", "structdecode__ctx__t.html", "structdecode__ctx__t" ],
    [ "driver", "structdriver.html", "structdriver" ],
    [ "flaglist", "structflaglist.html", "structflaglist" ],
    [ "gap_state", "structgap__state.html", "structgap__state" ],
    [ "ir_code_node", "structir__code__node.html", "structir__code__node" ],
    [ "ir_ncode", "structir__ncode.html", "structir__ncode" ],
    [ "ir_remote", "structir__remote.html", "structir__remote" ],
    [ "lengths", "structlengths.html", "structlengths" ],
    [ "lengths_state", "structlengths__state.html", "structlengths__state" ],
    [ "lirc_cmd_ctx", "structlirc__cmd__ctx.html", "structlirc__cmd__ctx" ],
    [ "lirc_code", "structlirc__code.html", "structlirc__code" ],
    [ "lirc_config", "structlirc__config.html", "structlirc__config" ],
    [ "lirc_config_entry", "structlirc__config__entry.html", "structlirc__config__entry" ],
    [ "lirc_list", "structlirc__list.html", "structlirc__list" ],
    [ "main_state", "structmain__state.html", "structmain__state" ],
    [ "option_t", "structoption__t.html", "structoption__t" ],
    [ "opts", "structopts.html", "structopts" ],
    [ "toggle_state", "structtoggle__state.html", "structtoggle__state" ]
];
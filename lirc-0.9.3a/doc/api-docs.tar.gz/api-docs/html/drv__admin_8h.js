var drv__admin_8h =
[
    [ "drv_guest_func", "drv__admin_8h.html#a66ecd0448214de7b954a4c0307fc1e4b", null ],
    [ "plugin_guest_func", "drv__admin_8h.html#a061d49469cbffaa34c2b73062a2607ab", null ],
    [ "for_each_driver", "drv__admin_8h.html#a6611f353b900834d1db0df47632be2ef", null ],
    [ "for_each_plugin", "drv__admin_8h.html#a9b76aa2090cad96593984bd833c3484c", null ],
    [ "hw_choose_driver", "drv__admin_8h.html#a1eaff4902d2d278d2d42e47e763c89da", null ],
    [ "hw_print_drivers", "drv__admin_8h.html#af73a4ec1270778bae0a0376af1c79b6b", null ]
];
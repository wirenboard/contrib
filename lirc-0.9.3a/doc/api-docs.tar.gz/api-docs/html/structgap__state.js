var structgap__state =
[
    [ "end", "structgap__state.html#a8f6f190e444ffad920e10396f510cac8", null ],
    [ "flag", "structgap__state.html#a00e219c6542de9f69213fc376563fe2d", null ],
    [ "gap", "structgap__state.html#a8319a5164281a8c0d091a79c7da22ec2", null ],
    [ "gaps", "structgap__state.html#aa14424ea3bece83d89e02ad3e21e9a45", null ],
    [ "last", "structgap__state.html#aadc03d0fc889f30353ed117b8a63d3ed", null ],
    [ "lastmaxcount", "structgap__state.html#a3db1727dd63fa84bc79c76bc17ff56ba", null ],
    [ "maxcount", "structgap__state.html#a4fc7abe6f436e49e5f3695acd0e44f76", null ],
    [ "scan", "structgap__state.html#a6a6f182a2a2f544b6aa7fa27a3b46a49", null ],
    [ "start", "structgap__state.html#a0a63e439b07df1971f37dae97c2d6f2f", null ]
];